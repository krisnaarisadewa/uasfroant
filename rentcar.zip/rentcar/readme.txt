I Nyoman Agus Krisna Adi Pranata
220030631

Kadek Wahyu Adinatha
220030651

I Made Duwyk Stifen
220030642

Kelas : BD223